//
//  DetailViewController.h
//  CookNook
//
//  Created by Davina Zahabian on 4/27/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import <UIKit/UIKit.h>

//typedef void (^CompletionHandler)(NSString *title, UIImage *image, NSString *ingredients, NSString *instructions);


@interface DetailViewController : UIViewController

//// completion handler for segue
//@property (copy, nonatomic) CompletionHandler completionHandler;

// data to populate view controller
@property (strong, nonatomic)  NSString *recipeName;
@property (strong, nonatomic)  UIImage *image;
@property (strong, nonatomic)  NSString *ingredients;
@property (strong, nonatomic)  NSString *instructions;

@end

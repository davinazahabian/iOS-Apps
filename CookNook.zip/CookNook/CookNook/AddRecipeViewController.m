//
//  AddRecipeViewController.m
//  CookNook
//
//  Created by Davina Zahabian on 4/26/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import "AddRecipeViewController.h"


@interface AddRecipeViewController () <UIImagePickerControllerDelegate, UINavigationControllerDelegate,UITextFieldDelegate, UITextViewDelegate>

@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UITextView *ingredientsTextView;
@property (weak, nonatomic) IBOutlet UITextView *instructionsTextView;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *saveButton;

@end



@implementation AddRecipeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    // set delegates
    self.nameTextField.delegate = self;
    self.ingredientsTextView.delegate = self;
    self.instructionsTextView.delegate = self;
    
    // save button disabled before text in text fields
    [self.saveButton setEnabled:NO];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}


// make keyboard disappear
- (IBAction)backgroundButtonPressed:(id)sender {
    [self.nameTextField resignFirstResponder];
    [self.ingredientsTextView resignFirstResponder];
    [self.instructionsTextView resignFirstResponder];
}


// enable save button only when there is text in all fields (does not need to have an image necessarily)
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (self.nameTextField.text.length <= 0 || self.ingredientsTextView.text.length <= 0 || self.instructionsTextView.text.length <= 0) {
        [self.saveButton setEnabled:NO];
    } else {
        [self.saveButton setEnabled:YES];
    }
    return YES;
}

// enable save button only when there is text in all fields (does not need to have an image necessarily)
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if (self.nameTextField.text.length <= 0 || self.ingredientsTextView.text.length <= 0 || self.instructionsTextView.text.length <= 0) {
        [self.saveButton setEnabled:NO];
    } else {
        [self.saveButton setEnabled:YES];
    }
    return YES;
}

//- (BOOL) textFieldShouldReturn:(UITextField *)textField {
//    [textField resignFirstResponder];
//    if (self.completionHandler) {
//        self.completionHandler(self.nameTextField.text, self.imageView.image, self.ingredientsTextView.text, self.instructionsTextView.text);
//    }
//    
//    // clear all fields
//    self.nameTextField.text = nil;
//    self.imageView.image = nil;
//    self.ingredientsTextView.text = nil;
//    self.instructionsTextView.text = nil;
//    return true;
//}

- (IBAction)saveButtonPressed:(id)sender {
    // resign first responder
    
    if (self.completionHandler) {
        self.completionHandler(self.nameTextField.text, self.imageView.image, self.ingredientsTextView.text, self.instructionsTextView.text);
    }
    // clear all fields
    self.nameTextField.text = nil;
    self.imageView.image = nil;
    self.ingredientsTextView.text = nil;
    self.instructionsTextView.text = nil;

}
- (IBAction)cancelButtonPressed:(id)sender {
    // resign first responder
    
    if (self.completionHandler) {
        self.completionHandler(nil,nil,nil,nil);
    }
    // clear all fields
    self.nameTextField.text = nil;
    self.imageView.image = nil;
    self.ingredientsTextView.text = nil;
    self.instructionsTextView.text = nil;
}

// image picker stuff:
- (IBAction)addSnapshotPressed:(id)sender {
    // use image picker to get an image from user's photo library, set it as the ImageView
    // for picking a photo:
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:picker animated:YES completion:NULL];
}

// get selected image and set as imageView on the view controller
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    self.imageView.image = chosenImage;
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

// when the user clicks cancel on the image picker
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}

@end

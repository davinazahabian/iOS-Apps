//
//  DetailViewController.m
//  CookNook
//
//  Created by Davina Zahabian on 4/27/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import "DetailViewController.h"
#import <FBSDKShareKit/FBSDKShareKit.h>

@interface DetailViewController ()

@property (weak, nonatomic) IBOutlet UILabel *recipeNameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *ingredientsLabel;
@property (weak, nonatomic) IBOutlet UILabel *instructionsLabel;

@end



@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    // set data to UI components
    [self.recipeNameLabel setText:_recipeName];
    [self.imageView setImage:_image];
    [self.ingredientsLabel setText:_ingredients];
    [self.instructionsLabel setText:_instructions];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


- (IBAction)backButtonPressed:(id)sender {
    // resign first responder
    [self resignFirstResponder];
}

@end

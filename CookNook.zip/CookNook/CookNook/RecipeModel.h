//
//  RecipeModel.h
//  CookNook
//
//  Created by Davina Zahabian on 4/25/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//
//
//  This class has an NSMutableArray of recipes, which will be stored as NSDictionary objects consisting of title (String), image (UIImage), ingredients (String), and instructions (String) of the recipes. It serves as the singleton model of data for an instance of the app. Will be used to populate the RecipeTableViewController, and the information will persist in memory.

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

// dictionary keys
static NSString * const kTitleKey = @"title";
static NSString * const kImageKey = @"image";
static NSString * const kIngredientsKey = @"ingredients";
static NSString * const kInstructionsKey = @"instructions";

@interface RecipeModel : NSObject

+ (instancetype) sharedModel;

// returns number of recipes
- (NSUInteger) numRecipes;

// gets recipe at given index
- (NSDictionary *) recipeAtIndex: (NSInteger) index;

//// adds recipe to the model
//- (void) insertRecipe: (NSDictionary *) recipe;

// adds recipe components into an NSDictionary and inserts
- (void) insertRecipeWithTitle: (NSString *) title
                         image: (UIImage *) image
                   ingredients: (NSString *) ingredients
                  instructions: (NSString *) instructions;

// removes recipe from the model
- (void) removeRecipeAtIndex: (NSUInteger) index;

@end

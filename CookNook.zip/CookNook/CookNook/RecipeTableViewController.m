//
//  RecipeTableViewController.m
//  CookNook
//
//  Created by Davina Zahabian on 4/25/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//
//
// This class extends UITableViewController to provide a table view of the user's recipes. Users may edit (delete) recipes, add recipes, and tap on a recipe (UITableViewCell) to view details and have the option to share that recipe.

#import "RecipeModel.h"
#import "RecipeTableViewController.h"
#import "AddRecipeViewController.h"
#import "DetailViewController.h"


@interface RecipeTableViewController ()

// singleton data model for all recipes
@property (strong,nonatomic) RecipeModel *model;

@end


@implementation RecipeTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // instantiate the shared model
    self.model = [RecipeModel sharedModel];
    
    // display an Edit button in the navigation bar for this view controller.
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // only one section is necessary
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section {
    // will want to return number of recipes
    return [self.model numRecipes];

}

// configure a table cell
- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"RecipeCell";
    UITableViewCell *cell = [tableView
        dequeueReusableCellWithIdentifier:CellIdentifier
                             forIndexPath:indexPath];
    
    // Configure the cell: what is being displayed in each cell (image and text)
    NSDictionary *recipe = [self.model recipeAtIndex:
                            indexPath.row];
    
    // set text of the cell
    cell.textLabel.text = recipe[kTitleKey];
    
    // set image of the cell
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:recipe[kImageKey]];
    UIImage *img = [UIImage imageWithContentsOfFile:getImagePath];
    cell.imageView.image = img;
    
    return cell;
}

//editing the table view
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [self.model removeRecipeAtIndex:indexPath.row];
        // Delete the row from the view
        [tableView deleteRowsAtIndexPaths:@[indexPath]
                         withRowAnimation:UITableViewRowAnimationFade];
        
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    // check which segue is used:
    if ([[segue identifier] isEqualToString:@"addSegue"]) {
        AddRecipeViewController *arvc = segue.destinationViewController;
        arvc.completionHandler = ^(NSString *title, UIImage *image, NSString *ingredients, NSString *instructions) {
            [self.model insertRecipeWithTitle:title
                                        image: image
                                  ingredients:ingredients
                                 instructions:instructions];
            [self.tableView reloadData];
            [self dismissViewControllerAnimated:YES completion:nil];
        };
        
    } else if ([[segue identifier] isEqualToString:@"detailSegue"]) {
        NSIndexPath *selectedIndexPath = [self.tableView indexPathForSelectedRow];
        NSDictionary * recipe = [self.model recipeAtIndex:selectedIndexPath.row];
        // get image of this recipe from image file
        NSString * imageFile = recipe[kImageKey];
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *getImagePath = [documentsDirectory stringByAppendingPathComponent:imageFile];
        UIImage *img = [UIImage imageWithContentsOfFile:getImagePath];
        // instantiate view controller, passing the data to populate fields
        DetailViewController *dvc = segue.destinationViewController;
        dvc.recipeName = recipe[kTitleKey];
        dvc.image = img;
        dvc.ingredients = recipe[kIngredientsKey];
        dvc.instructions = recipe[kInstructionsKey];
//        dvc.completionHandler = ^(NSString *title, UIImage *image, NSString *ingredients, NSString *instructions) {
//            [self.tableView reloadData];
//            [self dismissViewControllerAnimated:YES completion:nil];
//        };
    }
}

@end

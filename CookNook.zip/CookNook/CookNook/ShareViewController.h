//
//  ShareViewController.h
//  CookNook
//
//  Created by Davina Zahabian on 4/27/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//
//
// This class is the view controller that displays the login button, allowing a user to login to their Facebook account

#import <UIKit/UIKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>

@interface ShareViewController : UIViewController

@end

//
//  AppDelegate.h
//  CookNook
//
//  Created by Davina Zahabian on 4/27/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


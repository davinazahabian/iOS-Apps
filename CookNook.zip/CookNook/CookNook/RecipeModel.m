//
//  RecipeModel.m
//  CookNook
//
//  Created by Davina Zahabian on 4/25/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//
//
//  This class has an NSMutableArray of recipes, which will be stored as NSDictionary objects consisting of title (String), image (UIImage), ingredients (String), and instructions (String) of the recipes. It serves as the singleton model of data for an instance of the app. Will be used to populate the RecipeTableViewController, and the information will persist in memory.

#import "RecipeModel.h"


// filename for data persistence
static NSString *const kRecipesPList = @"Recipes.plist";


@interface RecipeModel ()

// stores the recipes of this app instance
@property (strong,nonatomic) NSMutableArray *recipes;

// the file path string for plist
@property (strong, nonatomic) NSString *filepathPlist;

@end



@implementation RecipeModel

- (instancetype) init {
    self = [super init];
    if (self) {
        
        // set up plist
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        _filepathPlist = [documentsDirectory stringByAppendingPathComponent:kRecipesPList];
        _recipes = [NSMutableArray arrayWithContentsOfFile:_filepathPlist];
        
        if(_recipes == nil){
            _recipes = [[NSMutableArray alloc] init];        }
        
    }
    return self;
}

// create the shared model
+ (instancetype) sharedModel {
    // class method -- will be accessing a static data member that is shared
    static RecipeModel *_sharedModel = nil;
    
    static dispatch_once_t onceToken;
    // code block
    dispatch_once(&onceToken, ^{
        // code to be executed once - thread-safe version
        _sharedModel = [[self alloc] init];
    });
    return _sharedModel;
}

// returns number of recipes
- (NSUInteger) numRecipes {
    return self.recipes.count;
}

// gets recipe at given index
- (NSDictionary *) recipeAtIndex: (NSInteger) index {
    return [self.recipes objectAtIndex:index];
}

// adds recipe (given as the recipe components) to the NSMutableArray, saving image to Documents and other info to plist
- (void) insertRecipeWithTitle: (NSString *) title
                         image: (UIImage *) image
                   ingredients: (NSString *) ingredients
                  instructions: (NSString *) instructions {
    
    // create file name for image
    NSString * imageFile = [NSString stringWithFormat:@"%lu.png", (unsigned long)self.numRecipes];

    // save the image to Documents
    NSArray * paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString * documentsDirectory = [paths objectAtIndex:0];
    NSString *savedImagePath = [documentsDirectory stringByAppendingPathComponent:imageFile];
    NSData *imageData = UIImagePNGRepresentation(image);
    [imageData writeToFile:savedImagePath atomically:NO];
    
    // save image file name to recipe object, along with other components
    NSDictionary * recipe = [[NSDictionary alloc] initWithObjectsAndKeys:
                             title, kTitleKey,
                             imageFile, kImageKey,
                             ingredients, kIngredientsKey,
                             instructions, kInstructionsKey, nil];
    
    // insert into array
    [self.recipes insertObject:recipe
                       atIndex:self.recipes.count];
    
    // save the recipe to the plist
    [self save];
    
}

// removes recipe from the model
- (void) removeRecipeAtIndex: (NSUInteger) index {
    
    // retrieve file name of image for deletion
    NSString *imageFile = [self.recipes objectAtIndex:index][kImageKey];
    
    // first remove recipe and update plist
    [self.recipes removeObjectAtIndex: index];
    
    // then remove image from Documents
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *filePath = [documentsPath stringByAppendingPathComponent:imageFile];
    NSError *error;
    [fileManager removeItemAtPath:filePath error:&error];
    
    [self save];
}

// save the recipes to plist
- (void) save {
    [self.recipes writeToFile:self.filepathPlist atomically:YES];
}

@end

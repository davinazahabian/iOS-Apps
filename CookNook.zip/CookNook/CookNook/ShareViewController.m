//
//  ShareViewController.m
//  CookNook
//
//  Created by Davina Zahabian on 4/27/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//
// This class is the view controller that displays the login button, allowing a user to login to their Facebook account

#import "ShareViewController.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>


@interface ShareViewController ()<FBSDKLoginButtonDelegate>

@end


@implementation ShareViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // add Facebook login button
   }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    FBSDKLoginButton *loginButton = [[FBSDKLoginButton alloc] init];
    // Place the button in the center of your view.
    loginButton.center = self.view.center;
    // Handle clicks on the button
    // permissions
    loginButton.delegate = self;
    loginButton.readPermissions =
    @[@"public_profile", @"email", @"user_friends"];
    
    [self.view addSubview:loginButton];
    
}

-(void)loginButton:(FBSDKLoginButton *)loginButton didCompleteWithResult:(FBSDKLoginManagerLoginResult *)result error:(NSError *)error{
    // user logged in here 
}

@end

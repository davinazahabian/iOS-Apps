//
//  RecipeTableViewController.h
//  CookNook
//
//  Created by Davina Zahabian on 4/25/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//
// This class extends UITableViewController to provide a table view of the user's recipes. Users may edit (delete) recipes, add recipes, and tap on a recipe (UITableViewCell) to view details and have the option to share that recipe.

#import <UIKit/UIKit.h>

@interface RecipeTableViewController : UITableViewController

@end

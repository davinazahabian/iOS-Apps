//
//  AddRecipeViewController.h
//  CookNook
//
//  Created by Davina Zahabian on 4/26/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^CompletionHandler)(NSString *title, UIImage *image, NSString *ingredients, NSString *instructions);

@interface AddRecipeViewController : UIViewController

@property (copy, nonatomic) CompletionHandler completionHandler;

@end
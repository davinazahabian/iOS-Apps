//
//  ViewController.m
//  Lab#2
//
//  Created by Davina Zahabian on 1/27/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UILabel *messageLabel;

@end

@implementation ViewController

- (IBAction)appleButtonTouched:(id)sender {
    NSString *name = self.nameTextField.text;
    if ([name length] > 0) {
        self.messageLabel.text = [NSString stringWithFormat:@"Good job, %@, you've made the right choice!", name];
    }
    else {
        self.messageLabel.text = [NSString stringWithFormat:@"Good job, you've made the right choice!"];
    }
}

- (IBAction)windowsButtonTouched:(id)sender {
    NSString *name = self.nameTextField.text;
    if ([name length] > 0) {
        self.messageLabel.text = [NSString stringWithFormat:@"Hey %@, I think you've made a mistake!", name];
    }
    else {
        self.messageLabel.text = [NSString stringWithFormat:@"Hey I think you've made a mistake!"];
    }
}

// keyboard will go away after return is pressed
- (IBAction)textFieldEdited:(id)sender {
    [sender resignFirstResponder];
}

// keyboard will go away after background is touched
- (IBAction)backgroundTouched:(id)sender {
    [self.nameTextField resignFirstResponder];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

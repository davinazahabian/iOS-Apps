//
//  ViewController.h
//  Lab#2
//
//  Created by Davina Zahabian on 1/27/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end


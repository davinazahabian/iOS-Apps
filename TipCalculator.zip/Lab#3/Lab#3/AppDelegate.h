//
//  AppDelegate.h
//  Lab#3
//
//  Created by Davina Zahabian on 2/8/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


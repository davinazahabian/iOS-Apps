//
//  ViewController.m
//  Lab#3
//
//  Created by Davina Zahabian on 2/8/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

// bill view
@property (weak, nonatomic) IBOutlet UITextField *billLabel;
@property (weak, nonatomic) IBOutlet UISegmentedControl *taxSegControl;
@property (weak, nonatomic) IBOutlet UILabel *taxLabel;
// tip view
@property (weak, nonatomic) IBOutlet UILabel *totalForTipLabel;
@property (weak, nonatomic) IBOutlet UILabel *percentLabel;

@property (weak, nonatomic) IBOutlet UILabel *evenSplitLabel;
@property (weak, nonatomic) IBOutlet UISwitch *tipSwitch;
@property (weak, nonatomic) IBOutlet UIStepper *splitStepper;
@property (weak, nonatomic) IBOutlet UISlider *tipSlider;
// summary view
@property (weak, nonatomic) IBOutlet UILabel *tipAmountLabel;
@property (weak, nonatomic) IBOutlet UILabel *totalWithTipLabel;
@property (weak, nonatomic) IBOutlet UILabel *totalPerPersonLabel;


// data
@property float billAmount;
@property float taxPercent;
@property float taxAmount;
@property float tipPercent;
@property float tipAmount;
@property float totalForTip;
@property float totalWithTip;
@property float totalSplit;
@property int splitNum;
@property BOOL includeTax;

@end

@implementation ViewController
// sets default values, called upon initial launch in viewDidLoad & clearAll
- (void)setDefaultValues {
    self.billAmount = 0.0;
    self.taxPercent = 0.0;
    self.taxAmount = 0.0;
    
    self.tipPercent = 0.0;
    self.totalForTip = 0.0;
    self.splitNum = 0;
    self.includeTax = false;
    
    self.tipAmount = 0.0;
    self.totalWithTip = 0.0;
    self.totalSplit = 0.0;

}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self setDefaultValues];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// updates the appropriate properties and labels when everything is changed
- (void)updateValues {
    // bill view
    self.billAmount = [self.billLabel.text floatValue];
    self.taxPercent = 7.5 + (self.taxSegControl.selectedSegmentIndex*0.5);
    self.taxAmount = self.billAmount*(self.taxPercent/100.0);
    self.taxLabel.text = [[NSNumber numberWithFloat:self.taxAmount] stringValue];
    // tip view
    if (self.tipSwitch.isEnabled) {
        self.totalForTip = self.billAmount + self.taxAmount;
    }
    else {
        self.totalForTip = self.billAmount;
    }
    self.totalForTipLabel.text = [[NSNumber numberWithFloat:self.totalForTip] stringValue];
    self.tipPercent = self.tipSlider.value;
    self.percentLabel.text = [[NSString alloc] initWithFormat: [[NSNumber numberWithFloat:self.tipPercent] stringValue], @"%%"];
    self.splitNum = self.splitStepper.value;
    self.evenSplitLabel.text = [[NSNumber numberWithFloat:self.splitNum] stringValue];
    // summary view
    self.tipAmount = self.totalForTip*(self.tipPercent/100.0);
    self.tipAmountLabel.text = [[NSNumber numberWithFloat:self.tipAmount] stringValue];
    self.totalWithTip = self.billAmount + self.totalForTip;
    self.totalWithTipLabel.text = [[NSNumber numberWithFloat:self.totalWithTip] stringValue];
    self.totalSplit = self.totalWithTip/self.splitNum;
    self.totalPerPersonLabel.text = [[NSNumber numberWithFloat:self.totalSplit] stringValue];
}

// calls setDefaultValues and resets UI components to their default values
- (void)clearAll {
    [self setDefaultValues];
    self.billLabel.text = [[NSNumber numberWithFloat:self.billAmount] stringValue];
    self.taxLabel.text = [[NSNumber numberWithFloat:self.taxAmount] stringValue];
    self.totalForTipLabel.text = [[NSNumber numberWithFloat:self.totalForTip] stringValue];
    self.percentLabel.text = [[NSNumber numberWithFloat:self.tipPercent] stringValue];
    self.evenSplitLabel.text = [[NSNumber numberWithFloat:self.splitNum] stringValue];
    self.totalWithTipLabel.text = [[NSNumber numberWithFloat:self.totalWithTip] stringValue];
    self.totalPerPersonLabel.text = [[NSNumber numberWithFloat:self.totalWithTip] stringValue];
    self.tipAmountLabel.text = [[NSNumber numberWithFloat:self.tipAmount] stringValue];
}

- (IBAction)billDidEndOnExit:(id)sender {
    [self updateValues];
}
- (IBAction)taxPercentChanged:(id)sender {
    //self.taxPercent = 7.5 + (self.taxSegControl.selectedSegmentIndex*0.5);
    [self updateValues];
}
- (IBAction)tipPercentChanged:(id)sender {
    
    [self updateValues];
}
- (IBAction)tipSwitchChanged:(id)sender {
    [self updateValues];
}
- (IBAction)stepperChanged:(id)sender {
    [self updateValues];
}

// background button pressed
- (IBAction)hideKeyboard:(id)sender {
    [self updateValues];
    [self.billLabel resignFirstResponder];
}

- (IBAction)clearAllPressed:(id)sender {
    NSString* alertControllerTitle = @"Clear All Values";
    NSString* destructiveTitle = @"Are you sure you want to clear all values?";
    NSString* clearAllTitle = @"Clear All";
    NSString* cancelTitle = @"Cancel";
    
    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:alertControllerTitle
                                                            message:destructiveTitle
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* clearAllAction = [UIAlertAction actionWithTitle:clearAllTitle
                                                   style:UIAlertActionStyleDestructive
                                                   handler:^(UIAlertAction* action) {
                                                        [self clearAll];
                                                        [alertController dismissViewControllerAnimated:YES completion:nil];
                                                   }];
    
    UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:cancelTitle
                                                 style:UIAlertActionStyleCancel
                                                 handler:^(UIAlertAction*action) {
                                                     [alertController dismissViewControllerAnimated:YES completion:nil];
                                                 }];
    
    [alertController addAction:clearAllAction];
    [alertController addAction:cancelAction];
    [self presentViewController:alertController animated:YES completion:nil];
}


@end

//
//  FavoritesTableViewController.h
//  Lab#5
//
//  Created by Davina Zahabian on 4/28/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavoritesTableViewController : UITableViewController

@end

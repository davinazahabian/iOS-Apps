//
//  FlashcardsModel.h
//  Lab#5
//
//  Created by Davina Zahabian on 3/30/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import <Foundation/Foundation.h>

// static constants for the keys
static NSString * const kQuestionKey = @"question";
static NSString * const kAnswerKey = @"answer";

@interface FlashcardsModel : NSObject
@property (strong, nonatomic) NSNumber *currentIndex;

// public methods to implement
+ (instancetype) sharedModel;
- (NSDictionary *) randomFlashcard;
- (NSUInteger) numberOfFlashcards;
- (NSDictionary *) flashcardAtIndex: (NSUInteger) index;
- (void) removeFlashcardAtIndex: (NSUInteger) index;
- (void) insertFlashcard: (NSDictionary *) flashcard;
- (void) insertFlashcard: (NSString *) question
                  answer: (NSString *) answer;
- (void) insertFlashcard: (NSDictionary *) flashcard
                 atIndex: (NSUInteger) index;
- (void) insertFlashcard: (NSString *) flashcard
                  answer: (NSString *) answer
                 atIndex: (NSUInteger) index;
- (NSDictionary *) nextFlashcard;
- (NSDictionary *) prevFlashcard;
- (BOOL) isFavorite: (NSDictionary *) flashcard;
- (void) removeFavorite: (NSDictionary *) favorite;
- (void) removeFavoriteAtIndex: (NSUInteger) index;
- (void) insertFavorite: (NSDictionary *) favorite;
- (NSUInteger) numberOfFavorites;
- (NSDictionary *) favoriteAtIndex: (NSUInteger) index;
- (void) removeAllFavorites;

@end


//
//  FlashcardsModel.m
//  Lab#5
//
//  Created by Davina Zahabian on 3/30/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//



#import "FlashcardsModel.h"

// filename for flashcards data
static NSString *const kFlashcardsPList = @"Flashcards.plist";
// filename for favorites data
static NSString *const kFavoritesPList = @"Favorites.plist";

@interface FlashcardsModel ()

// mutable array containing dictionary objects: question, answer
@property (strong, nonatomic) NSMutableArray *flashcards;
// the flashcards file path
@property (strong, nonatomic) NSString *flashFilepath;
// the favorites file path
@property (strong, nonatomic) NSString *favoritesFilepath;
// favorites array
@property (strong, nonatomic) NSMutableArray *favorites;

@end


@implementation FlashcardsModel

// init method to initialize flashcards array
- (instancetype)init
{
    self = [super init];
    if (self) {        
        // set up flashcards
        NSArray *paths1 = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory1 = [paths1 objectAtIndex:0];
        _flashFilepath = [documentsDirectory1 stringByAppendingPathComponent:kFlashcardsPList];
        _flashcards = [NSMutableArray arrayWithContentsOfFile:_flashFilepath];
        
        // set up favorites
        NSArray *paths2 = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory2 = [paths2 objectAtIndex:0];
        _favoritesFilepath = [documentsDirectory2 stringByAppendingPathComponent:kFavoritesPList];
        _favorites = [NSMutableArray arrayWithContentsOfFile:_favoritesFilepath];
        NSString * str = [NSString stringWithFormat:@"%lu",(unsigned long)self.favorites.count];
        NSLog(str);
        
        // set current index
        self.currentIndex = [NSNumber numberWithInt:0];
        
        if (_flashcards == nil) {
            // create a bunch of NSDictionary objects with questions and answers
            // at least 5 flash cards
            NSDictionary *flash1 = [[NSDictionary alloc] initWithObjectsAndKeys:@"What are the two types of methods in Objective-C?", kQuestionKey, @"Instance and Class Methods", kAnswerKey, nil];
        
            NSDictionary *flash2 = [[NSDictionary alloc] initWithObjectsAndKeys:@"Why do we use the @property directive?", kQuestionKey, @"To automatically generate getters and setters", kAnswerKey, nil];
        
            NSDictionary *flash3 = [[NSDictionary alloc] initWithObjectsAndKeys:@"What is the dot notation equivalent of calling the getter [self property] ?", kQuestionKey, @"self.property", kAnswerKey, nil];
        
            NSDictionary *flash4 = [[NSDictionary alloc] initWithObjectsAndKeys:@"What is an IBOutlet?", kQuestionKey, @"An instance variable that is connected to an object in Interface Builder", kAnswerKey, nil];
        
            NSDictionary *flash5 = [[NSDictionary alloc] initWithObjectsAndKeys:@"What is an IBAction?", kQuestionKey, @"A method you want a user interface object to be able to call", kAnswerKey, nil];
        
            // load dictionary objects into mutable array
            _flashcards = [[NSMutableArray alloc] initWithObjects:flash1, flash2, flash3, flash4, flash5, nil];
            
            [self saveFlashcard];
        }
    }
    return self;
}


+ (instancetype) sharedModel {
    // class method -- will be accessing a static data member that is shared
    static FlashcardsModel *_sharedModel = nil;
    
    static dispatch_once_t onceToken;
    // code block
    dispatch_once(&onceToken, ^{
        // code to be executed once - thread-safe version
        _sharedModel = [[self alloc] init];
    });
    return _sharedModel;
}

- (NSDictionary *) randomFlashcard {
    NSUInteger num = arc4random() % [self numberOfFlashcards];
    self.currentIndex = [NSNumber numberWithInteger:num];
    return [self.flashcards objectAtIndex:self.currentIndex.integerValue];
}

- (NSUInteger) numberOfFlashcards {
    return self.flashcards.count;
}

- (NSDictionary *) flashcardAtIndex: (NSUInteger) index {
    if (index <self.flashcards.count) {
        // return this card
        return [self.flashcards objectAtIndex:index];
    } else {
        // return 0th card
        return [self.flashcards objectAtIndex:0];
    }
}


// call similar NSMutableArray methods
- (void) removeFlashcardAtIndex: (NSUInteger) index {
    if (index < self.flashcards.count) {
        [self.flashcards removeObjectAtIndex: index];
    }
    else {
        [self.flashcards removeObjectAtIndex: (self.flashcards.count-1)];
    }
    [self saveFlashcard];
}

- (void) insertFlashcard: (NSDictionary *) flashcard {
    [self.flashcards insertObject:flashcard
                          atIndex:self.flashcards.count];
    [self saveFlashcard];
}

- (void) insertFlashcard: (NSString *) question
                  answer: (NSString *) answer {
    NSDictionary *flash = [[NSDictionary alloc] initWithObjectsAndKeys:question, kQuestionKey, answer, kAnswerKey, nil];
    [self.flashcards insertObject:flash
                          atIndex:self.flashcards.count];
    [self saveFlashcard];
}

- (void) insertFlashcard: (NSDictionary *) flashcard
                 atIndex: (NSUInteger) index {
    if (index <= self.flashcards.count) {
        [self.flashcards insertObject:flashcard
                              atIndex:index];
    }
    else {
        [self.flashcards insertObject:flashcard
                              atIndex:self.flashcards.count];
    }
    [self saveFlashcard];
}

- (void) insertFlashcard: (NSString *) flashcard
                  answer: (NSString *) answer
                 atIndex: (NSUInteger) index {
    NSDictionary *flash = [[NSDictionary alloc] initWithObjectsAndKeys:flashcard, kQuestionKey, answer, kAnswerKey, nil];
    if (index <= self.flashcards.count) {
        [self.flashcards insertObject:flash
                              atIndex:index];
    }
    else {
        [self.flashcards insertObject:flash
                              atIndex:self.flashcards.count];
    }
    [self saveFlashcard];
}

// increment currentIndex and go to that card, if at the end go back to 0
- (NSDictionary *) nextFlashcard {
    NSUInteger num = [self.currentIndex intValue]+1;
    
    if (num == self.flashcards.count) {
        self.currentIndex = [NSNumber numberWithInteger:0];
        return [self.flashcards objectAtIndex:self.currentIndex.integerValue];
    }
    else {
        self.currentIndex = [NSNumber numberWithInteger:num];
        return [self.flashcards objectAtIndex:self.currentIndex.integerValue];
    }
}

// decrement currentIndex and go to that card, if at the beginning go to end
- (NSDictionary *) prevFlashcard {
    NSUInteger num = [self.currentIndex intValue];
    
    if (num == 0) {
        self.currentIndex = [NSNumber numberWithInteger:(self.flashcards.count-1)];
        return [self.flashcards objectAtIndex:self.currentIndex.integerValue];
    }
    else {
        self.currentIndex = [NSNumber numberWithInteger:num-1];
        return [self.flashcards objectAtIndex:self.currentIndex.integerValue];
    }
}

// save the flashcard
- (void) saveFlashcard {
    [self.flashcards writeToFile:self.flashFilepath atomically:YES];
}



// favorites:

// add a favorite
- (NSUInteger) numberOfFavorites {
    return self.favorites.count;
}

- (NSDictionary *) favoriteAtIndex: (NSUInteger) index {
    if (index <self.favorites.count) {
        // return this card
        return [self.favorites objectAtIndex:index];
    } else {
        // return 0th card
        return [self.favorites objectAtIndex:0];
    }
}


// call similar NSMutableArray methods
- (void) removeFavorite: (NSDictionary *) favorite {
    [self.favorites removeObject:favorite];
    [self saveFavorite];
}

- (void) removeFavoriteAtIndex: (NSUInteger) index {
    [self.favorites removeObjectAtIndex:index];
    [self saveFavorite];
}

- (void) insertFavorite: (NSDictionary *) favorite {
    [self.favorites insertObject:favorite
                          atIndex:self.favorites.count];

    [self saveFavorite];
    NSString * size = [NSString stringWithFormat:@"%lu",(unsigned long)self.favorites.count];
    NSLog(size);
}

- (void) insertFavorite: (NSString *) question
                  answer: (NSString *) answer {
    NSDictionary *favorite = [[NSDictionary alloc] initWithObjectsAndKeys:question, kQuestionKey, answer, kAnswerKey, nil];
    [self.favorites insertObject:favorite
                          atIndex:self.favorites.count];
    [self saveFavorite];
}

- (void) insertFavorite: (NSDictionary *) favorite
                 atIndex: (NSUInteger) index {
    if (index <= self.favorites.count) {
        [self.favorites insertObject:favorite
                              atIndex:index];
    }
    else {
        [self.favorites insertObject:favorite
                              atIndex:self.favorites.count];
    }
    [self saveFavorite];
}

- (void) insertFavorite: (NSString *) favorite
                  answer: (NSString *) answer
                 atIndex: (NSUInteger) index {
    NSDictionary *fav = [[NSDictionary alloc] initWithObjectsAndKeys:favorite, kQuestionKey, answer, kAnswerKey, nil];
    if (index <= self.favorites.count) {
        [self.favorites insertObject:fav
                              atIndex:index];
    }
    else {
        [self.favorites insertObject:fav
                              atIndex:self.favorites.count];
    }
    [self saveFavorite];
}

// check if given flashcard is in favorites
- (BOOL) isFavorite: (NSDictionary *) flashcard {
    for (int i=0; i<self.favorites.count; i++) {
        if ([self favoriteAtIndex:i] == flashcard) {
            return YES;
        }
    }
    return NO;
}

- (void) removeAllFavorites {
    self.favorites = nil;
    [self saveFavorite];
}

// save the favorite
- (void) saveFavorite {
    NSLog(@"save to favorite");
    [self.favorites writeToFile:self.favoritesFilepath atomically:YES];
}

@end
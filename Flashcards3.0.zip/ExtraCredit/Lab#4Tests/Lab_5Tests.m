//
//  Lab_5Tests.m
//  Lab#5Tests
//
//  Created by Davina Zahabian on 3/30/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "FlashcardsModel.h"

@interface Lab_5Tests : XCTestCase

@property (strong, nonatomic) FlashcardsModel *testModel;

@end

@implementation Lab_5Tests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
    
    self.testModel = [[FlashcardsModel alloc] init];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void) logArray {
    NSDictionary * flashcard;
    for (NSUInteger i=0; i< [self.testModel numberOfFlashcards]; i++) {
        flashcard = [self.testModel flashcardAtIndex:i];
        NSLog(@"%@ %@", flashcard[kQuestionKey],
              flashcard[kAnswerKey]);
    }
    NSLog(@" ");
}

- (void)modelTest {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
    // init creates 5 flashcards
    NSUInteger num;
    NSDictionary *flashcard;
    
    // make sure correct number created
    num = 5;
    XCTAssertEqual(num, [self.testModel numberOfFlashcards]);
    
    flashcard = [NSDictionary dictionaryWithObjectsAndKeys:
             @"What is the parent language of Objective-C?", kQuestionKey,
             @"The C Programming Language", kAnswerKey, nil];
    // insertFlashcard:
    [self.testModel insertFlashcard:flashcard];
    num = num+1;
    XCTAssertEqual(num, [self.testModel numberOfFlashcards]);
    [self logArray];
    XCTAssertEqualObjects([self.testModel flashcardAtIndex:num-1], flashcard);
    
    // removeFlashcardAtIndex:
    [self.testModel removeFlashcardAtIndex:0];
    num = num - 1;
    [self logArray];
    
    // insertFlashcard:answer
    [self.testModel insertFlashcard:@"What are the two types of files?" answer:@".h and .m"];
    num = num+1;
    XCTAssertEqual(num, [self.testModel numberOfFlashcards]);
    XCTAssertEqualObjects(@"What are the two types of files?",[self.testModel flashcardAtIndex:num-1][kQuestionKey]);
    XCTAssertEqualObjects(@".h and .m",[self.testModel flashcardAtIndex:num-1][kAnswerKey]);    
    [self logArray];

    
    // insertFlashcard:atIndex:
    [self.testModel insertFlashcard:flashcard atIndex:3];
    num = num+1;
    XCTAssertEqual(num, [self.testModel numberOfFlashcards]);
    XCTAssertEqualObjects(flashcard, [self.testModel flashcardAtIndex:3]);
    [self logArray];
    
    // insertFlashcard:answer:atIndex
    [self.testModel insertFlashcard:@"What is singleton?" answer:@"A special kind of class where only one instance of the class exists for the current process." atIndex:2];
    num = num+1;
    XCTAssertEqual(num, [self.testModel numberOfFlashcards]);
    XCTAssertEqualObjects(@"What is singleton?", [self.testModel flashcardAtIndex:2][kQuestionKey]);
    XCTAssertEqualObjects(@"A special kind of class where only one instance of the class exists for the current process.", [self.testModel flashcardAtIndex:2][kAnswerKey]);
    [self logArray];

}

@end

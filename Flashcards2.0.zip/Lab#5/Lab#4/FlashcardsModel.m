//
//  FlashcardsModel.m
//  Lab#5
//
//  Created by Davina Zahabian on 3/30/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//



#import "FlashcardsModel.h"

// filename for data
static NSString *const kFlashcardsPList = @"Flashcards.plist";

@interface FlashcardsModel ()

// mutable array containing dictionary objects: question, answer
@property (strong, nonatomic) NSMutableArray *flashcards;
// current index used by next]Flashcard and prevFlashcard
@property (strong, nonatomic) NSNumber *currentIndex;
// the file path
@property (strong, nonatomic) NSString *filepath;

@end


@implementation FlashcardsModel

// init method to initialize flashcards array
- (instancetype)init
{
    self = [super init];
    if (self) {
        // set up plist
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        _filepath = [documentsDirectory stringByAppendingPathComponent:kFlashcardsPList];
        _flashcards = [NSMutableArray arrayWithContentsOfFile:_filepath];
        
        // set current index
        self.currentIndex = [NSNumber numberWithInt:0];
        
        if (_flashcards == nil) {
            // create a bunch of NSDictionary objects with questions and answers
            // at least 5 flash cards
            NSDictionary *flash1 = [[NSDictionary alloc] initWithObjectsAndKeys:@"What are the two types of methods in Objective-C?", kQuestionKey, @"Instance and Class Methods", kAnswerKey, nil];
        
            NSDictionary *flash2 = [[NSDictionary alloc] initWithObjectsAndKeys:@"Why do we use the @property directive?", kQuestionKey, @"To automatically generate getters and setters", kAnswerKey, nil];
        
            NSDictionary *flash3 = [[NSDictionary alloc] initWithObjectsAndKeys:@"What is the dot notation equivalent of calling the getter [self property] ?", kQuestionKey, @"self.property", kAnswerKey, nil];
        
            NSDictionary *flash4 = [[NSDictionary alloc] initWithObjectsAndKeys:@"What is an IBOutlet?", kQuestionKey, @"An instance variable that is connected to an object in Interface Builder", kAnswerKey, nil];
        
            NSDictionary *flash5 = [[NSDictionary alloc] initWithObjectsAndKeys:@"What is an IBAction?", kQuestionKey, @"A method you want a user interface object to be able to call", kAnswerKey, nil];
        
            // load dictionary objects into mutable array
            _flashcards = [[NSMutableArray alloc] initWithObjects:flash1, flash2, flash3, flash4, flash5, nil];
            
            [self save];
        }
    }
    return self;
}

+ (instancetype) sharedModel {
    // class method -- will be accessing a static data member that is shared
    static FlashcardsModel *_sharedModel = nil;
    
    static dispatch_once_t onceToken;
    // code block
    dispatch_once(&onceToken, ^{
        // code to be executed once - thread-safe version
        _sharedModel = [[self alloc] init];
    });
    return _sharedModel;
}

- (NSDictionary *) randomFlashcard {
    NSUInteger num = arc4random() % [self numberOfFlashcards];
    self.currentIndex = [NSNumber numberWithInteger:num];
    return [self.flashcards objectAtIndex:self.currentIndex.integerValue];
}

- (NSUInteger) numberOfFlashcards {
    return self.flashcards.count;
}

- (NSDictionary *) flashcardAtIndex: (NSUInteger) index {
    if (index <self.flashcards.count) {
        // return this card
        return [self.flashcards objectAtIndex:index];
    } else {
        // return 0th card
        return [self.flashcards objectAtIndex:0];
    }
}


// call similar NSMutableArray methods
- (void) removeFlashcardAtIndex: (NSUInteger) index {
    if (index < self.flashcards.count) {
        [self.flashcards removeObjectAtIndex: index];
    }
    else {
        [self.flashcards removeObjectAtIndex: (self.flashcards.count-1)];
    }
    [self save];
}

- (void) insertFlashcard: (NSDictionary *) flashcard {
    [self.flashcards insertObject:flashcard
                          atIndex:self.flashcards.count];
    [self save];
}

- (void) insertFlashcard: (NSString *) question
                  answer: (NSString *) answer {
    NSDictionary *flash = [[NSDictionary alloc] initWithObjectsAndKeys:question, kQuestionKey, answer, kAnswerKey, nil];
    [self.flashcards insertObject:flash
                          atIndex:self.flashcards.count];
    [self save];
}

- (void) insertFlashcard: (NSDictionary *) flashcard
                 atIndex: (NSUInteger) index {
    if (index <= self.flashcards.count) {
        [self.flashcards insertObject:flashcard
                              atIndex:index];
    }
    else {
        [self.flashcards insertObject:flashcard
                              atIndex:self.flashcards.count];
    }
    [self save];
}

- (void) insertFlashcard: (NSString *) flashcard
                  answer: (NSString *) answer
                 atIndex: (NSUInteger) index {
    NSDictionary *flash = [[NSDictionary alloc] initWithObjectsAndKeys:flashcard, kQuestionKey, answer, kAnswerKey, nil];
    if (index <= self.flashcards.count) {
        [self.flashcards insertObject:flash
                              atIndex:index];
    }
    else {
        [self.flashcards insertObject:flash
                              atIndex:self.flashcards.count];
    }
    [self save];
}

// increment currentIndex and go to that card, if at the end go back to 0
- (NSDictionary *) nextFlashcard {
    NSUInteger num = [self.currentIndex intValue]+1;
    
    if (num == self.flashcards.count) {
        self.currentIndex = [NSNumber numberWithInteger:0];
        return [self.flashcards objectAtIndex:self.currentIndex.integerValue];
    }
    else {
        self.currentIndex = [NSNumber numberWithInteger:num];
        return [self.flashcards objectAtIndex:self.currentIndex.integerValue];
    }
}

// decrement currentIndex and go to that card, if at the beginning go to end
- (NSDictionary *) prevFlashcard {
    NSUInteger num = [self.currentIndex intValue];
    
    if (num == 0) {
        self.currentIndex = [NSNumber numberWithInteger:(self.flashcards.count-1)];
        return [self.flashcards objectAtIndex:self.currentIndex.integerValue];
    }
    else {
        self.currentIndex = [NSNumber numberWithInteger:num-1];
        return [self.flashcards objectAtIndex:self.currentIndex.integerValue];
    }
}

// save the flashcards
- (void) save {
    [self.flashcards writeToFile:self.filepath atomically:YES];
}

@end
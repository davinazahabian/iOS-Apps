//
//  ViewController.m
//  Lab#5
//
//  Created by Davina Zahabian on 3/30/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import "ViewController.h"
#import "FlashcardsModel.h"
#import <AudioToolbox/AudioToolbox.h>

@interface ViewController ()

// private property for the model
@property (strong, nonatomic) FlashcardsModel *model;
// current flashcard's answer
@property (strong, nonatomic) NSDictionary *current;
// audio files
@property (readonly) SystemSoundID soundFileIDTada;
@property (readonly) SystemSoundID soundFileIDFadeIn;

// IBOutlets
// label displaying flashcard text
@property (weak, nonatomic) IBOutlet UILabel *flashcardLabel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    #if TARGET_IPHONE_SIMULATOR
        NSLog(@"Documents Directory: %@", [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject]);
    #endif
    
    // Do any additional setup after loading the view, typically from a nib.
    
    // set up audio property
    // new card = fade in, answer = tada
    NSString *soundFilePathTada = [[NSBundle mainBundle]
                                   pathForResource:@"TaDa" ofType:@"wav"];
    NSString *soundFilePathFadeIn = [[NSBundle mainBundle]
                                     pathForResource:@"fadein" ofType:@"wav"];
    NSURL *soundURLTada = [NSURL fileURLWithPath:soundFilePathTada];
    NSURL *soundURLFadeIn = [NSURL fileURLWithPath:soundFilePathFadeIn];
    AudioServicesCreateSystemSoundID((__bridge CFURLRef)soundURLTada, &_soundFileIDTada);
    AudioServicesCreateSystemSoundID((__bridge CFURLRef)soundURLFadeIn, &_soundFileIDFadeIn);
    
    // create the model by calling sharedModel, get first or random flashcard and show it on screen
    self.model = [FlashcardsModel sharedModel];
    if ([self.model numberOfFlashcards] == 0) {
        [self fadeInFlashcard:@"There are no more flashcards."];
    } else {
        self.current = [self.model randomFlashcard];
        [self fadeInFlashcard:self.current[kQuestionKey]];        
    }

    
    // gesture recognizers
    // single tap
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapRecognized:)];
    [self.view addGestureRecognizer:singleTap];
    
    // double tap
    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTapRecognized:)];
    doubleTap.numberOfTapsRequired = 2;
    [self.view addGestureRecognizer:doubleTap];
    
    // only recognize single taps if they're not the first of two
    [singleTap requireGestureRecognizerToFail:doubleTap];
    
    // swipe gestures
    // swipe left
    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeGestureRecognized:)];
    swipeLeft.direction = UISwipeGestureRecognizerDirectionLeft;
    [self.view addGestureRecognizer:swipeLeft];
    
    // swipe right
    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeGestureRecognized:)];
    swipeRight.direction = UISwipeGestureRecognizerDirectionRight;
    [self.view addGestureRecognizer:swipeRight];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// gesture methods
// question = red, answer = black
// single tap = next card
- (void) singleTapRecognized: (UITapGestureRecognizer *) recognizer {
    if ([self.model numberOfFlashcards] == 0) {
        [self fadeOutFlashcard:@"There are no more flashcards."];
    } else {
        self.current = [self.model randomFlashcard];
        [self fadeOutFlashcard:self.current[kQuestionKey]];
    }

}
// double tap = answer of card
- (void) doubleTapRecognized: (UITapGestureRecognizer *) recognizer {
    if ([self.model numberOfFlashcards] == 0) {
        [self fadeOutFlashcard:@"Please add more flashcards."];
    } else {
        [self fadeOutFlashcard:self.current[kAnswerKey]];
    }

}
// swipe left and right
- (void) swipeGestureRecognized: (UISwipeGestureRecognizer *) recognizer {
    if ([self.model numberOfFlashcards] == 0) {
        [self fadeOutFlashcard:@"There are no more flashcards."];
    } else {
        if (recognizer.direction == UISwipeGestureRecognizerDirectionLeft) {
            self.current = [self.model prevFlashcard];
        } else if (recognizer.direction == UISwipeGestureRecognizerDirectionRight) {
            self.current = [self.model nextFlashcard];
        }
        [self fadeOutFlashcard:self.current[kQuestionKey]];
    }
}

// shake gesture
- (BOOL) canBecomeFirstResponder {
    return YES;
}
- (void) viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self becomeFirstResponder];
}
- (void) motionEnded:(UIEventSubtype)motion
           withEvent:(UIEvent *)event {
    if (motion == UIEventSubtypeMotionShake) {
        if ([self.model numberOfFlashcards] == 0) {
            [self fadeOutFlashcard:@"There are no more flashcards."];
        } else {
            self.current = [self.model randomFlashcard];
            [self fadeOutFlashcard:self.current[kQuestionKey]];
        }
    }
}

// animation
// fade in text with color
- (void) fadeInFlashcard: (NSString *) string {
    // insert text
    self.flashcardLabel.alpha = 0;
    self.flashcardLabel.text = string;
    
    if (string == self.current[kQuestionKey]) {
        self.flashcardLabel.textColor = [UIColor magentaColor];
    }
    else {
        self.flashcardLabel.textColor = UIColor.blueColor;
    }
    [UIView animateWithDuration:1.0
        animations:^{
            self.flashcardLabel.alpha = 1;
            if (string == self.current[kQuestionKey]) {
                AudioServicesPlaySystemSound(self.soundFileIDFadeIn);
            } else {
                AudioServicesPlaySystemSound(self.soundFileIDTada);
            }
        }
     ];
}
// fade out old text and fade in new text with color
- (void) fadeOutFlashcard: (NSString *) string {
    [UIView animateWithDuration:1.0
        animations:^{
            self.flashcardLabel.alpha = 0;
        }
        completion:^(BOOL finished) {
            [self fadeInFlashcard:string];
        }
     ];
}

@end

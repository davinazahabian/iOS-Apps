//
//  AddViewController.h
//  Lab#5
//
//  Created by Davina Zahabian on 4/6/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^CompletionHandler)(NSString *questionText, NSString *answerText);

@interface AddViewController : UIViewController

@property (copy, nonatomic) CompletionHandler completionHandler;

@end

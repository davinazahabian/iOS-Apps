//
//  AddViewController.m
//  Lab#5
//
//  Created by Davina Zahabian on 4/6/16.
//  Copyright © 2016 Davina Zahabian. All rights reserved.
//

#import "AddViewController.h"


// adhere to the protocols
@interface AddViewController () <UITextFieldDelegate, UITextViewDelegate>

@property (weak, nonatomic) IBOutlet UITextView *addTextView;
@property (weak, nonatomic) IBOutlet UITextField *addTextField;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *saveButton;


@end

@implementation AddViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.saveButton setEnabled:NO];
    // Do any additional setup after loading the view.
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.addTextView becomeFirstResponder];
}
- (IBAction)backgroundTouched:(id)sender {
    [self.addTextView resignFirstResponder];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (self.addTextView.text.length >= 9 && self.addTextField.text.length >= 9) {
        [self.saveButton setEnabled:YES];
    } else {
        [self.saveButton setEnabled:NO];
    }
    return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if (self.addTextView.text.length >= 9 && self.addTextField.text.length >= 9) {
        [self.saveButton setEnabled:YES];
    } else {
        [self.saveButton setEnabled:NO];
    }
    return YES;
}

- (IBAction)savePressed:(id)sender {
    // resign first responder
    
    if (self.completionHandler) {
        self.completionHandler(self.addTextView.text, self.addTextField.text);
    }
    self.addTextView.text = nil;
    self.addTextField.text = nil;

}
- (IBAction)cancelPressed:(id)sender {
    // resign first responder
    
    if (self.completionHandler) {
        self.completionHandler(nil, nil);
        
    }
    self.addTextView.text = nil;
    self.addTextField.text = nil;
}

- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    if (self.completionHandler) {
        self.completionHandler(self.addTextView.text, self.addTextField.text);
    }
    
    self.addTextView.text = nil;
    self.addTextField.text = nil;
    return true;
}

// UITextViewDelegate and UITextFieldDelegate methods


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}


@end
